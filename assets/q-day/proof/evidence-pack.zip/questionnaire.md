# Procurement / Auditor Questionnaire — answered from the CBOM

© 2026 Joshua Dawson / J-Dawgs Industries

## Do you maintain a cryptographic inventory (CBOM)?
Yes — this pack is generated from it. 37 cryptographic assets inventoried.

## Which post-quantum algorithms are in your environment today?
None detected yet — all inventoried asymmetric cryptography is classical. See migration plan.

## Which classical algorithms remain in use, and where?
Shor-broken algorithms in use: ECDH ×1, ECDSA ×4, RSA ×12. Full locations in inventory.csv.

## What is your exposure to harvest-now-decrypt-later collection?
HIGH harvest-now exposure: 4 asset(s) — Shor-broken crypto protecting data with 5+ year secrecy lifetime. MEDIUM: 0. Assume recorded traffic and archived ciphertext are already collected; migration priority follows data lifetime, not system age.

## Which mandates govern your migration, and what are the deadlines?
NSA CNSA 2.0 — software & firmware signing — deadline 2030-12-31 (14 asset(s)) NSA CNSA 2.0 — traditional networking equipment — deadline 2030-12-31 (1 asset(s)) NSA CNSA 2.0 — web, cloud services, operating systems — deadline 2033-12-31 (14 asset(s)) EO 14412 / OMB M-26-15 — federal key establishment (incl. covered contractors via FAR) — deadline 2030-12-31 (4 asset(s)) EO 14412 / OMB M-26-15 — federal digital signatures — deadline 2031-12-31 (14 asset(s)) NIST IR 8547 — classical public-key algorithms deprecated (all approved strengths) — deadline 2030-12-31 (26 asset(s)) NIST IR 8547 — classical public-key algorithms disallowed (all approved strengths) — deadline 2035-12-31 (26 asset(s)) NSM-10 — national security systems transition complete — deadline 2035-12-31 (21 asset(s))

## What is the migration sequence and target completion?
Sequenced in Phase 1 (Fix first — broken & harvest-now-critical): 16 item(s), window: Start now; complete within 12 months; Phase 2 (The 2030 wall): 10 item(s), window: Complete by 2030-12-31; Phase 3 (The 2031 signature wave): 0 item(s), window: Complete by 2031-12-31; Phase 4 (Completion & standardization (2033–2035)): 11 item(s), window: Complete by 2035-12-31. Total planning-estimate effort: 231 engineer-days.

## Which assets protect data with a secrecy lifetime of 5+ years?
RSA at certs/root-ca.der (5 yr); ECDSA at certs/server-ec.pem (5 yr); RSA at certs/server-rsa.pem (5 yr); UNKNOWN at firmware/bootloader.bin (10 yr); UNKNOWN at firmware/firmware-v3.bin (10 yr); RSA at firmware/firmware-v3.p7s (10 yr)

## Do any systems still negotiate TLS 1.0 / 1.1 or use MD5 / SHA-1 / DES / RC4?
Yes — DES at src/Service.java:16; DES at src/app.py:20; MD5 at src/Service.java:7; MD5 at src/app.py:10; MD5 at src/main.go:7; SHA-1 at src/app.py:13; SHA-1 at src/web.js:5

## Who owns this inventory and when was it produced?
Produced locally by Q-Day Ledger™ v1.0.1-vault2 from scanner output; no source code or key material left the operator's machine. Asset-level evidence is in inventory.csv / risk-register.csv.
